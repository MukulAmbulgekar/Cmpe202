package composite;


/**
 * Write a description of interface Burger here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface CustomBurger
{
   public double getBurgerCost();
}
